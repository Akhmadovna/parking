public class CarType {

    public static String EMPTY_SIGN = "✅";
    public static String POLICE_CAR = "\uD83D\uDE93";
    public static String MINIBUS = "\uD83D\uDE90";
    public static String AUTOMOBILE = "\uD83D\uDE97";
    public static String BUS = "\uD83D\uDE8C";

}
