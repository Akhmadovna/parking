public class Parking {
    private String name;
    private Cell[][] building;

    public Parking(String name) {
        this.name = name;
    }
    public void availableCount(){
        int countAvailable = 0;
        for (int i = 0; i < building.length; i++) {
            for (int j = 0; j < building[i].length; j++) {
                Cell cell = building[i][j];
                if (cell.isEmpty()){
                    countAvailable++;
                }
            }
        }
        System.out.println("Count Available = " + countAvailable);
    }public void notAvailableCount(){
        int countNotAvailable = 0;
        for (int i = 0; i < building.length; i++) {
            for (int j = 0; j < building[i].length; j++) {
                Cell cell = building[i][j];
                if (!cell.isEmpty()){
                    countNotAvailable++;
                }
            }
        }
        System.out.println("Count Not Available = " + countNotAvailable);
    }
    public void buildPark(int rows, int cols) {
        building = new Cell[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                building[i][j] = new Cell();
            }
        }
    }

    public void displayPark() {
        System.out.println("-----");
        for (int i = 0; i < building.length; i++) {
            for (int j = 0; j < building[i].length; j++) {
                Cell cell = building[i][j];
                if (cell.isEmpty()) {
                    System.out.print(" " + CarType.EMPTY_SIGN + " ");
                } else {
                    System.out.print(" " + cell.getCar().getCarType() + " ");
                }
            }
            System.out.println();
        }
        System.out.println("-----");
    }
    public void park(String serial, int row, int col){
        Cell cell = building[row][col];
        if (!cell.isEmpty()){
            if (serial.equals(cell.getCar().getSerial())){
                System.out.println("Parking is done");
                cell.getCar().setCarType(CarType.EMPTY_SIGN);
                return;
            }else {
                System.out.println("This car number not found");
            }
        }else {
            System.out.println("This cell is empty");
        }
    }
    public void park(Car car, int row, int col) {
        Cell cell = building[row][col];
        if (!cell.isEmpty()) {
            System.out.println("WARNING !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.print("This Cell is not empty");
            System.out.println("Please select other cell");
            return;
        }
        cell.setCar(car);
        cell.setEmpty(false);
    }
    public String getName() {
        return name;
    }
}